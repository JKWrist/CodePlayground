#ifndef AHSAPI_INTERFACE_H
#define AHSAPI_INTERFACE_H
#include <stdbool.h>
#include "cJSON.h"

typedef enum {
	AHSAPI_SUCESS = 0,         //sucess
	AHSAPI_INVALID_COMMAND,    //invalid command
	AHSAPI_INVALID_ARGUMENT,   //invalid argument
	AHSAPI_METHOD_NO_FOUND,    //method no found
	AHSAPI_NOT_FOUND,          //no found    
	AHSAPI_RESP_NO_DATA,       //no response data
	AHSAPI_PERMISSION_DENIED,  //Permission denied
	AHSAPI_REQUEST_TIMED_OUT,   // time out 
	AHSAPI_OPERATION_NOT_SUPPORTED, // Operation not supported
	AHSAPI_UNKNOW_ERROR,		//Unknow error
	AHSAPI_CONNECTION_FAILED,   //Connection failed
}ahsapi_resp_code_t ;

typedef int (*ahsapi_event_cb_handler_t)(char *event_type,cJSON *event_data);

/***ahsapi 串口开关***/
int ahsapi_debug_enable(bool flag); 

/***设备基本信息***/

int ahsapi_get_version(char *var,int var_len); //获取ahsapi 版本号
int ahsapi_get_devbasic_info(cJSON **basicInfo); //获取组网设备基本信息

/***设备硬件信息***/
int ahsapi_get_hardware_info(cJSON ** hardWareInfo);//获取组网设备硬件信息

/***设备端口信息***/
int ahsapi_get_port_info(cJSON **portInfo);  //获取组网设备端口信息

/***设备上行信息***/
int ahsapi_get_uplink_info(cJSON **uplinkInfo); //获取组网设备上行状态信息
int ahsapi_set_pppoe(const char *user,const char *pwd); //配置pppoe账号密码
int ahsapi_set_wlan_connect(char *ssid, char *pwd,char* securityMode); //配置wlan上行时接入SSID和密码
int ahsapi_set_work_mode(int mode,int type);//配置工作模式
int	ahsapi_set_uplink_rate_config(char *ifType,char *reportInterval ,char *sampleInterval);//配置上行周期和采样
//int	ahsapi_get_uplink_rate_config(char *reportInterval ,char *sampleInterval, int len);//获取上行周期和采样



/***下挂设备信息***/
int ahsapi_get_sta_info(cJSON ** staInfo);  //获取下挂设备列表信息
int ahsapi_get_sta_num(cJSON ** staNum); //获取下挂设备数量信息
int	ahsapi_set_sta_rate_config(char* ifType,char *reportInterval ,char *sampleInterval);//配置下挂设备周期和采样
//int	ahsapi_get_sta_rate_config(char *reportInterval ,char *sampleInterval,int len);//获取下挂设备周期和采样


/***设备wifi 信息***/
int ahsapi_get_wifi_info(cJSON ** wifiInfo); 	// 获取wifi配置信息
int ahsapi_set_wifi_parameter(cJSON * wifiParameter);	 // 配置wifi参数
int ahsapi_set_wifi_switch(char *radio, int enable,int index);	// 配置wifi开关
int ahsapi_set_radio_config(cJSON * radioConfig);  // 配置wifi功率
int ahsapi_set_wps(char *radio);  // 配置wps
int ahsapi_set_5GPreferred(char *preferredSta,int limitTime); //配置5G优先


int ahsapi_set_csi_enable(char * radio, int csiEnable); //配置csi 开关
int ahsapi_set_csi_mac(int csiMacAction,char * csiMacEntris); //配置获取csi 下挂设备白名单
int ahsapi_get_csi_mac(char * csiMacEntris); //获取csi 下挂设备白名单
int ahsapi_set_csi_config(int csiInterval,int frameMode); //配置csi 采集参数
int ahsapi_get_csi_config(cJSON ** csiConfig); //获取csi采集配置参数

/***设备wifi 统计***/
int ahsapi_get_wifi_stats_info(cJSON ** wifiStatsInfo); //获取wifi统计信息

/***设备周边wifi ***/
int ahsapi_get_wlan_neighbor_info(cJSON ** wlanNeighborInfo); //获取周边wifi信息

/***漫游***/
int ahsapi_get_roaming_config(cJSON ** roamingConfig); // 获取组网设备漫游配置信息
int ahsapi_set_roaming_config(cJSON* roamingConfig); //配置漫游
int ahsapi_sta_disconnect(char* mac,int dismissTime); // 断开该STA 的连接，并限制接入dismissTime毫秒
int ahsapi_sta_rssi(char* mac,cJSON ** staRssi); //查询组网设备与STA的弱信号
int ahsapi_set_band_steering_config(cJSON * bandSteeringConfig);//配置双频合一
int ahsapi_get_band_steering_config(cJSON ** bandSteeringConfig);//获取双频合一配置
int ahsapi_sta_stop_detect(char* mac,long long stopDetectTime) ;//停止漫游策略



/***定时任务***/
int ahsapi_get_all_timed_task(cJSON** allTimedTask);  //获取所有定时任务配置信息
int ahsapi_add_timed_task(cJSON* timedTask);  //添加和更新定时任务
int ahsapi_delete_timed_task(int taskId);  // 删除定时任务

/***黑白名单***/
int ahsapi_set_mac_filter(cJSON* macFilter); // 设置黑白名单
int ahsapi_get_mac_filter(cJSON** macFilter); // 获取黑白名单配置

/***设备操作***/
int ahsapi_set_reboot(int controlType); // 组网设备重启操作
int ahsapi_set_reset();  // 组网设备恢复出厂
int ahsapi_set_led_control(int ledOnOFF); //组网设备led灯控
int ahsapi_set_firmware_upgrade(cJSON * upgrade); //组网设备固件升级
int ahsapi_set_lock_net (int lockStatus); // 配置锁网
int ahsapi_set_pmf_ctrl(int pmfEnable);
int ahsapi_get_control_status(cJSON **controlStatus); // 获取led灯控和锁网状态
int ahsapi_set_hwnat_clean(); //清空硬加速链路表
int ahsapi_set_kernel_count(int count);//配置硬加速，软件协议栈数据包数量
int ahsapi_set_dev_log_stats(cJSON * devLog,char* logPath,int len);//日志采集配置
int ahsapi_set_ipv6_control(int ipv6Enable);//ipv4/ipv6双栈功能开关


/***配置保存***/
int ahsapi_cfg_add_item(char* item , char* value); //配置保存
int ahsapi_cfg_get_item(char* item , char* value,int len); //配置获取
int ahsapi_cfg_delete_item(char* item); //配置删除
int ahsapi_get_cfg_path(int filetype, char* cfgPath, int len); //获取配置文件路径

/***mesh***/
int ahsapi_map_set_mesh_role(int role);  //配置mesh角色
int ahsapi_map_set_mesh_roaming(int enable); //配置mesh 漫游开关
int ahsapi_map_get_mesh_topology(cJSON **meshTopology); //获取mesh拓扑结构
int ahsapi_map_get_mesh_info(cJSON **meshInfo); // 获取mesh 信息


/***devicelimit***/
int ahsapi_set_device_limit(cJSON *deviceLimit); //配置设备网络限速
int ahsapi_get_device_limit(cJSON **deviceLimit); //获取设备网络限速

/***event***/
int ahsapi_event_listen_callback(ahsapi_event_cb_handler_t event_cb);
int ahsapi_event_listen_cancel();

/***detection****/
int  ahsapi_http_speed_test(cJSON *speedTest); //设备http下载测速

/***plugin**/
int ahsapi_get_tmpapp_path(char *tmpapp_path); //获取业务插件安装包路径
int ahsapi_plugin_event_send(cJSON * pluginEvent);//业务插件管理模块与业务插件消息发送接口

/***Qos/VLAN ***/
//int ahsapi_get_qos_config(cJSON** qosConfig); //获取qos配置
//int ahsapi_set_qos_config(cJSON* qosConfig); //配置qos
//int ahsapi_get_iptv_vlan_config(cJSON** iptvVlan); //获取iptv
//int ahsapi_set_iptv_vlan_config(cJSON* iptvVlan); //配置iptv





#endif
